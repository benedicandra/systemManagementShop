﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Partea1
{
    public partial class Menu1 : Form
    {
        public Menu1()
        {
            InitializeComponent();
            customizeDesign();
        }

        private void customizeDesign()
        {
            panelProducts.Visible = false;
            panel_Departments.Visible = false;
        }

        private void hideSubmenu()
        {
            if (panelProducts.Visible = true)
                panelProducts.Visible = false;
            if (panel_Departments.Visible = true)
                panel_Departments.Visible = false;
        }

        private void showSubMenu(Panel submenu){
            if (submenu.Visible == false)
            {
                hideSubmenu();
                submenu.Visible = true;

            }
            else
                submenu.Visible = false;

        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            showSubMenu(panelProducts);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddProduct frm = new AddProduct();
            frm.Show();
            hideSubmenu();
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            Find frm = new Find();
            frm.Show();
            hideSubmenu();
        }

        private void btn_Departments_Click(object sender, EventArgs e)
        {
            showSubMenu(panel_Departments);
        }

        private void btn_Cleaning_Click(object sender, EventArgs e)
        {
            Cleaning frm = new Cleaning();
            frm.Show();
            hideSubmenu();
        }

        private void btn_Electronics_Click(object sender, EventArgs e)
        {
            Electronics frm = new Electronics();
            frm.Show();
            hideSubmenu();
        }

        private void btn_Food_Click(object sender, EventArgs e)
        {
            Food frm = new Food();
            frm.Show();
            hideSubmenu();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Buy frm = new Buy();
            frm.Show();
            hideSubmenu();
        }

        private void btn_Graphic_Click(object sender, EventArgs e)
        {
            Stocks_Dep frm = new Stocks_Dep();
            frm.Show();
            hideSubmenu();
        }

        private void btn_Needs_Click(object sender, EventArgs e)
        {
            Needs frm = new Needs();
            frm.Show();
            hideSubmenu();
        }

        private void backgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    panelPrincipal.BackColor = cd.Color;
                    panelFooter.BackColor = cd.Color;
                    panelMenu.BackColor = cd.Color;
                    btnProducts.BackColor = cd.Color;
                    
                    btn_Departments.BackColor = cd.Color;
                    
                    btn_Buy.BackColor = cd.Color;
                    btn_Graphic.BackColor = cd.Color;
                    btn_Needs.BackColor = cd.Color;
                }
                    

            }
        }

        private void foregroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                   label1.ForeColor = cd.Color;
                   btnProducts.ForeColor = cd.Color;
                    btnAdd.ForeColor = cd.Color;
                    btn_Find.ForeColor = cd.Color;
                    btn_Departments.ForeColor = cd.Color;
                    btn_Electronics.ForeColor = cd.Color;
                    btn_Food.ForeColor = cd.Color;
                    btn_Cleaning.ForeColor = cd.Color;
                    btn_Buy.ForeColor = cd.Color;
                    btn_Graphic.ForeColor = cd.Color;
                    btn_Needs.ForeColor = cd.Color;

                }
                    

            }
        }

        private void backgroundToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    panelLogo.BackColor = cd.Color;
                    panel_Departments.BackColor = cd.Color;
                    panelProducts.BackColor = cd.Color;

                    btnAdd.BackColor = cd.Color;
                    btn_Find.BackColor = cd.Color;

                    btn_Electronics.BackColor = cd.Color;
                    btn_Food.BackColor = cd.Color;
                    btn_Cleaning.BackColor = cd.Color;

                }


            }
        }
    }
}
