﻿namespace Partea1
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.produsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alimenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.electroniceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.curatareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.graphicsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stocksDepartmentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.needsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.changeBackgroundColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.IndianRed;
            this.menuStrip1.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.produsToolStripMenuItem,
            this.buyToolStripMenuItem,
            this.buyToolStripMenuItem1,
            this.graphicsToolStripMenuItem,
            this.needsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(758, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // produsToolStripMenuItem
            // 
            this.produsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addProductToolStripMenuItem,
            this.findProductToolStripMenuItem});
            this.produsToolStripMenuItem.Name = "produsToolStripMenuItem";
            this.produsToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.produsToolStripMenuItem.Text = "Products";
            // 
            // addProductToolStripMenuItem
            // 
            this.addProductToolStripMenuItem.Name = "addProductToolStripMenuItem";
            this.addProductToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.addProductToolStripMenuItem.Text = "Add/Delete product";
            this.addProductToolStripMenuItem.Click += new System.EventHandler(this.addProductToolStripMenuItem_Click);
            // 
            // findProductToolStripMenuItem
            // 
            this.findProductToolStripMenuItem.Name = "findProductToolStripMenuItem";
            this.findProductToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.findProductToolStripMenuItem.Text = "Find product";
            this.findProductToolStripMenuItem.Click += new System.EventHandler(this.findProductToolStripMenuItem_Click);
            // 
            // buyToolStripMenuItem
            // 
            this.buyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alimenteToolStripMenuItem,
            this.electroniceToolStripMenuItem,
            this.curatareToolStripMenuItem});
            this.buyToolStripMenuItem.Name = "buyToolStripMenuItem";
            this.buyToolStripMenuItem.Size = new System.Drawing.Size(99, 20);
            this.buyToolStripMenuItem.Text = "Departments";
            // 
            // alimenteToolStripMenuItem
            // 
            this.alimenteToolStripMenuItem.Name = "alimenteToolStripMenuItem";
            this.alimenteToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.alimenteToolStripMenuItem.Text = "Food";
            this.alimenteToolStripMenuItem.Click += new System.EventHandler(this.alimenteToolStripMenuItem_Click);
            // 
            // electroniceToolStripMenuItem
            // 
            this.electroniceToolStripMenuItem.Name = "electroniceToolStripMenuItem";
            this.electroniceToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.electroniceToolStripMenuItem.Text = "Electronics";
            this.electroniceToolStripMenuItem.Click += new System.EventHandler(this.electroniceToolStripMenuItem_Click);
            // 
            // curatareToolStripMenuItem
            // 
            this.curatareToolStripMenuItem.Name = "curatareToolStripMenuItem";
            this.curatareToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.curatareToolStripMenuItem.Text = "Cleaning";
            this.curatareToolStripMenuItem.Click += new System.EventHandler(this.curatareToolStripMenuItem_Click);
            // 
            // buyToolStripMenuItem1
            // 
            this.buyToolStripMenuItem1.Name = "buyToolStripMenuItem1";
            this.buyToolStripMenuItem1.Size = new System.Drawing.Size(42, 20);
            this.buyToolStripMenuItem1.Text = "&Buy";
            this.buyToolStripMenuItem1.Click += new System.EventHandler(this.buyToolStripMenuItem1_Click);
            // 
            // graphicsToolStripMenuItem
            // 
            this.graphicsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stocksDepartmentsToolStripMenuItem});
            this.graphicsToolStripMenuItem.Name = "graphicsToolStripMenuItem";
            this.graphicsToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.graphicsToolStripMenuItem.Text = "Graphics";
            // 
            // stocksDepartmentsToolStripMenuItem
            // 
            this.stocksDepartmentsToolStripMenuItem.Name = "stocksDepartmentsToolStripMenuItem";
            this.stocksDepartmentsToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.stocksDepartmentsToolStripMenuItem.Text = "Stocks/Departments";
            this.stocksDepartmentsToolStripMenuItem.Click += new System.EventHandler(this.stocksDepartmentsToolStripMenuItem_Click);
            // 
            // needsToolStripMenuItem
            // 
            this.needsToolStripMenuItem.Name = "needsToolStripMenuItem";
            this.needsToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.needsToolStripMenuItem.Text = "&Needs";
            this.needsToolStripMenuItem.Click += new System.EventHandler(this.needsToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(151, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(423, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Shop Management Application";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeBackgroundColorToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(104, 48);
            // 
            // changeBackgroundColorToolStripMenuItem
            // 
            this.changeBackgroundColorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundColorToolStripMenuItem});
            this.changeBackgroundColorToolStripMenuItem.Name = "changeBackgroundColorToolStripMenuItem";
            this.changeBackgroundColorToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.changeBackgroundColorToolStripMenuItem.Text = "Color";
            // 
            // backgroundColorToolStripMenuItem
            // 
            this.backgroundColorToolStripMenuItem.Name = "backgroundColorToolStripMenuItem";
            this.backgroundColorToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.backgroundColorToolStripMenuItem.Text = "Background color";
            this.backgroundColorToolStripMenuItem.Click += new System.EventHandler(this.backgroundColorToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // clockControl11
            // 
            
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(758, 372);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu";
            this.Text = "Shop Management App";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem produsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buyToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem alimenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem electroniceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem curatareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buyToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem changeBackgroundColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem graphicsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stocksDepartmentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem needsToolStripMenuItem;
    }
}

