﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Partea1
{
    public partial class Food : Form
    {
        string connString;
        List<ProdusAlimentar> produseAl = new List<ProdusAlimentar>();

        public Food()
        {
            connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Products.accdb";
            InitializeComponent();
            //showProducts();
            showProductsDB();
        }

        //DISPLAY DATA FROM TEXT FILE IN LISTVIEW
        public void showProducts()
        {
            try
            {
                using (StreamReader sr = new StreamReader("food.txt"))
                {
                    string linie = null;
                    while ((linie = sr.ReadLine()) != null)
                    {
                        try
                        {
                            int cod = Convert.ToInt32(linie.Split(' ')[0]);
                            string denumire = linie.Split(' ')[1];
                            double stoc = Convert.ToDouble(linie.Split(' ')[2]);
                            double pret = Convert.ToDouble(linie.Split(' ')[3]);

                            ProdusAlimentar pa = new ProdusAlimentar(cod, denumire, stoc, pret);

                            produseAl.Add(pa);
                            
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                    sr.Close();
                }
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //MessageBox.Show("Data loaded!");
            foreach (ProdusAlimentar pa in produseAl)
            {
                ListViewItem itm = new ListViewItem(pa.CodProdus.ToString());
                itm.SubItems.Add(pa.DenumireProdus);
                itm.SubItems.Add(pa.Stoc.ToString());
                itm.SubItems.Add(pa.Pret.ToString());
                
                if (pa.Stoc > 0)
                {
                    itm.SubItems.Add("Available");
                }
                else
                {
                    itm.SubItems.Add("Unavailable");
                }


                listView1.Items.Add(itm);
            }
        }

        //DISPLAY DATA FROM DB IN LISTVIEW
        private void showProductsDB()
        {
            OleDbConnection conexiune = new OleDbConnection(connString);
            try
            {
                conexiune.Open();
                //MessageBox.Show("Data base conected!");
                //OleDbCommand comanda = new OleDbCommand("SELECT * FROM Products", conexiune);
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = conexiune;
                comanda.CommandText = "SELECT * FROM ProductsFood";

                OleDbDataReader reader = comanda.ExecuteReader();
                while (reader.Read())
                {
                    ListViewItem itm = new ListViewItem(reader["Id"].ToString());
                    itm.SubItems.Add(reader["Name"].ToString());
                    itm.SubItems.Add(reader["Price"].ToString());
                    itm.SubItems.Add(reader["Quantity"].ToString());


                    if (Convert.ToInt32(reader["Quantity"]) > 0)
                        itm.SubItems.Add("Available");
                    else
                        itm.SubItems.Add("Unavailable");

                    listView1.Items.Add(itm);
                }

                comanda.ExecuteNonQuery();
            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexiune.Close();
            }
        }


        //SAVE DATA IN TEXT FILE
        private async void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "(*.txt)|*.txt";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(new FileStream(dlg.FileName, FileMode.Create), Encoding.UTF8);
                {
                    foreach (ListViewItem item in listView1.Items)
                    {
                        await sw.WriteLineAsync(item.SubItems[0].Text + "\t" + item.SubItems[1].Text + "\t" + item.SubItems[2].Text + "\t" + item.SubItems[3].Text + "\t" + item.SubItems[4].Text);

                    }
                    MessageBox.Show("Your data has been succesfully exported!");
                }

                sw.Close();
                //listView1.Clear();
            }
        }

        //SAVE DATA IN XML FILE
        private void button1_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            XmlTextWriter w = new XmlTextWriter(ms,Encoding.UTF8);
            w.Formatting = Formatting.Indented;
            
            w.WriteStartDocument();
            w.WriteStartElement("Food department");

            foreach (ProdusAlimentar pa in produseAl)
            {
                w.WriteStartElement(pa.ToString());
                w.WriteEndElement();
            }
            
            w.WriteEndElement();
            w.WriteEndDocument();

            
            w.Close();

            string str = Encoding.UTF8.GetString(ms.ToArray());
            ms.Close();

            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "(*.xml)|*.xml";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(dlg.FileName);
                sw.WriteLine(str);
                sw.Close();
                MessageBox.Show("Your data has been succesfully exported!");
            }
          
        }

        //CONTEXT MENU STRIP
        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                    this.BackColor = cd.Color;

            }
        }

        private void fontColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                    this.ForeColor = cd.Color;

            }
        }
    }
}
