﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Partea1
{
    public abstract class Produs:ICloneable,IComparable, Itva
    {
        private int codProdus;
        private string denumireProd;
        private double stoc;
        private double pret;
        private int[] recenzii=null;//note produse

        public Produs()
        {
            codProdus = 0;
            denumireProd = "Product NONAME";
            stoc = 0;
            pret = 0;
            recenzii = null;
        }

        public Produs(int cod, string den, double stoc, double pret, int[] rec){
            this.codProdus = cod;
            this.denumireProd = den;
            this.stoc = stoc;
            this.pret = pret;
            this.recenzii = new int[rec.Length];
            for (int i = 0; i < rec.Length; i++)
                recenzii[i] = rec[i];
        }

        public Produs(int cod, string den, double pret, double stoc)
        {
            this.codProdus = cod;
            this.denumireProd = den;
            this.stoc = stoc;
            this.pret = pret;
        }

        public Produs(string den, double pret, double stoc)
        {
            this.denumireProd = den;
            this.stoc = stoc;
            this.pret = pret;
        }

        public double CalcTVA()
        {
            double pretCuTVA = this.pret;
            pretCuTVA = 1.19 * pretCuTVA;
            return pretCuTVA;
        }
        

        public object Clone()
        {
            Produs p = (Produs)this.MemberwiseClone();
            int[] recenzii2 = (int[])recenzii.Clone();
            p.recenzii = recenzii2;
            return p;
        }

        public int CompareTo(object obj)
        {
            return pret.CompareTo(obj);
        }

        public override string ToString()
        {
            string result = codProdus + " " + denumireProd +
                " " + stoc + " " + pret +" ";
            if (recenzii != null)
            {
 
                for (int i = 0; i < recenzii.Length; i++)
                    result += recenzii[i] + " ";
            }
            else
                result += "no reviews ";
            return result;
        }

     

        public int CodProdus
        {
            get { return this.codProdus; }

        }

        public string DenumireProdus
        {
            get { return this.denumireProd; }

        }
       

        public double Stoc
        {
            get { return this.stoc; }

        }
        public double Pret
        {
            get { return this.pret; }
            set
            {
                if (value > 0)
                    this.pret = value;
            }
        }



        public int this[int index]
        {
            get
            {
                if (recenzii != null && index >= 0 && index < recenzii.Length)
                    return recenzii[index];
                else
                    return 0;
            }
            set
            {
                if (value > 0 && value <= 10 && index >= 0 && index < recenzii.Length)
                    recenzii[index] = value;
            }
        }

    }
}
