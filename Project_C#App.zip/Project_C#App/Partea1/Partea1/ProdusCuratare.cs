﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Partea1
{
    public class ProdusCuratare:Produs,Itva
    {
        private string calitate="None";

        public ProdusCuratare() : base()
        {
        
        }
        public ProdusCuratare(int cod, string denumire, double stoc, double pret, int[] rec)
            : base(cod, denumire, stoc, pret,rec)
        {
        
        }

        public ProdusCuratare(int cod, string den, double pret, double stoc) 
            : base(cod, den, pret, stoc)
        {
        
        }

        public ProdusCuratare(string den, double pret, double stoc)
            : base(den, pret, stoc)
        {

        }

        /*public override string ToString()
        {
            string result = base.ToString() + " " + calitate;
            return result;
        }*/

        public string Calitate
        {
            get { return calitate; }
            set
            {
                if (value != null)
                    calitate = value;
            }
        }
    }
}
