﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Partea1
{
    public class Raion
    {
        private string denumireRaion;
        private List<Object> listaProduse = null;

        public Raion()
        {
            denumireRaion = "Raion NO NAME";
            listaProduse = null;
        }

        public Raion(string denumire, List<Object> lista)
        {
            this.denumireRaion = denumire;
            this.listaProduse = lista;
        }

        public List<Object> ListaProduse
        {
            get { return listaProduse; }
            set
            {
                if (value != null)
                    listaProduse = value;
            }
        }

        public string DenumireRaion
        {
            get { return this.denumireRaion; }
        }

        public static Raion operator +(Raion r, Object p)
        {
            r.listaProduse.Add(p);
            return r;
        }

        public static Raion operator -(Raion r, Object p)
        {
            r.listaProduse.Remove(p);
            return r;
        }
        
    }
}
