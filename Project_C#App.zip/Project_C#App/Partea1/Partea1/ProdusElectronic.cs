﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Partea1
{
    public class ProdusElectronic:Produs,Itva
    {
        private string garantie="None";

        public ProdusElectronic() : base()
        {
        }
        public ProdusElectronic(int cod, string denumire, double stoc, double pret, int[]rec)
            : base(cod, denumire, stoc, pret,rec)
        {
        }

        public ProdusElectronic(int cod, string denumire, double stoc, double pret)
            : base(cod, denumire, stoc, pret)
        {
        }

        public ProdusElectronic(string denumire, double stoc, double pret)
            : base(denumire, stoc, pret)
        {
        }

        public string Garantie
        {
            get { return garantie; }
            set
            {
                if (value != null)
                    garantie = value;
            }
        }
    }
}
