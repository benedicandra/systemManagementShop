﻿namespace Partea1
{
    partial class Menu1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu1));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btn_Needs = new System.Windows.Forms.Button();
            this.btn_Graphic = new System.Windows.Forms.Button();
            this.btn_Buy = new System.Windows.Forms.Button();
            this.panel_Departments = new System.Windows.Forms.Panel();
            this.btn_Food = new System.Windows.Forms.Button();
            this.btn_Electronics = new System.Windows.Forms.Button();
            this.btn_Cleaning = new System.Windows.Forms.Button();
            this.btn_Departments = new System.Windows.Forms.Button();
            this.panelProducts = new System.Windows.Forms.Panel();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnProducts = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.colorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panelFooter = new System.Windows.Forms.Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.colorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foregroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelPrincipal = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelMenu.SuspendLayout();
            this.panel_Departments.SuspendLayout();
            this.panelProducts.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.panelPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.AutoScroll = true;
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(44)))), ((int)(((byte)(87)))));
            this.panelMenu.Controls.Add(this.btn_Needs);
            this.panelMenu.Controls.Add(this.btn_Graphic);
            this.panelMenu.Controls.Add(this.btn_Buy);
            this.panelMenu.Controls.Add(this.panel_Departments);
            this.panelMenu.Controls.Add(this.btn_Departments);
            this.panelMenu.Controls.Add(this.panelProducts);
            this.panelMenu.Controls.Add(this.btnProducts);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Font = new System.Drawing.Font("Quicksand Book", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(201, 479);
            this.panelMenu.TabIndex = 0;
            // 
            // btn_Needs
            // 
            this.btn_Needs.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Needs.FlatAppearance.BorderSize = 0;
            this.btn_Needs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Needs.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Needs.Location = new System.Drawing.Point(0, 410);
            this.btn_Needs.Name = "btn_Needs";
            this.btn_Needs.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Needs.Size = new System.Drawing.Size(201, 40);
            this.btn_Needs.TabIndex = 7;
            this.btn_Needs.Text = "Needs";
            this.btn_Needs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Needs.UseVisualStyleBackColor = true;
            this.btn_Needs.Click += new System.EventHandler(this.btn_Needs_Click);
            // 
            // btn_Graphic
            // 
            this.btn_Graphic.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Graphic.FlatAppearance.BorderSize = 0;
            this.btn_Graphic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Graphic.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Graphic.Location = new System.Drawing.Point(0, 370);
            this.btn_Graphic.Name = "btn_Graphic";
            this.btn_Graphic.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Graphic.Size = new System.Drawing.Size(201, 40);
            this.btn_Graphic.TabIndex = 6;
            this.btn_Graphic.Text = "Graphics";
            this.btn_Graphic.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Graphic.UseVisualStyleBackColor = true;
            this.btn_Graphic.Click += new System.EventHandler(this.btn_Graphic_Click);
            // 
            // btn_Buy
            // 
            this.btn_Buy.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Buy.FlatAppearance.BorderSize = 0;
            this.btn_Buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Buy.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Buy.Location = new System.Drawing.Point(0, 330);
            this.btn_Buy.Name = "btn_Buy";
            this.btn_Buy.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Buy.Size = new System.Drawing.Size(201, 40);
            this.btn_Buy.TabIndex = 5;
            this.btn_Buy.Text = "Buy";
            this.btn_Buy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Buy.UseVisualStyleBackColor = true;
            this.btn_Buy.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel_Departments
            // 
            this.panel_Departments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(112)))), ((int)(((byte)(143)))));
            this.panel_Departments.Controls.Add(this.btn_Food);
            this.panel_Departments.Controls.Add(this.btn_Electronics);
            this.panel_Departments.Controls.Add(this.btn_Cleaning);
            this.panel_Departments.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Departments.Location = new System.Drawing.Point(0, 240);
            this.panel_Departments.Name = "panel_Departments";
            this.panel_Departments.Size = new System.Drawing.Size(201, 90);
            this.panel_Departments.TabIndex = 4;
            // 
            // btn_Food
            // 
            this.btn_Food.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(209)))), ((int)(((byte)(232)))));
            this.btn_Food.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Food.FlatAppearance.BorderSize = 0;
            this.btn_Food.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Food.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Food.Location = new System.Drawing.Point(0, 60);
            this.btn_Food.Name = "btn_Food";
            this.btn_Food.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Food.Size = new System.Drawing.Size(201, 30);
            this.btn_Food.TabIndex = 2;
            this.btn_Food.Text = "Food";
            this.btn_Food.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Food.UseVisualStyleBackColor = false;
            this.btn_Food.Click += new System.EventHandler(this.btn_Food_Click);
            // 
            // btn_Electronics
            // 
            this.btn_Electronics.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(209)))), ((int)(((byte)(232)))));
            this.btn_Electronics.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Electronics.FlatAppearance.BorderSize = 0;
            this.btn_Electronics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Electronics.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Electronics.Location = new System.Drawing.Point(0, 30);
            this.btn_Electronics.Name = "btn_Electronics";
            this.btn_Electronics.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Electronics.Size = new System.Drawing.Size(201, 30);
            this.btn_Electronics.TabIndex = 1;
            this.btn_Electronics.Text = "Electronics";
            this.btn_Electronics.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Electronics.UseVisualStyleBackColor = false;
            this.btn_Electronics.Click += new System.EventHandler(this.btn_Electronics_Click);
            // 
            // btn_Cleaning
            // 
            this.btn_Cleaning.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(209)))), ((int)(((byte)(232)))));
            this.btn_Cleaning.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Cleaning.FlatAppearance.BorderSize = 0;
            this.btn_Cleaning.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cleaning.Font = new System.Drawing.Font("Quicksand Book", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cleaning.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Cleaning.Location = new System.Drawing.Point(0, 0);
            this.btn_Cleaning.Name = "btn_Cleaning";
            this.btn_Cleaning.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Cleaning.Size = new System.Drawing.Size(201, 30);
            this.btn_Cleaning.TabIndex = 0;
            this.btn_Cleaning.Text = "Cleaning ";
            this.btn_Cleaning.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Cleaning.UseVisualStyleBackColor = false;
            this.btn_Cleaning.Click += new System.EventHandler(this.btn_Cleaning_Click);
            // 
            // btn_Departments
            // 
            this.btn_Departments.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Departments.FlatAppearance.BorderSize = 0;
            this.btn_Departments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Departments.Font = new System.Drawing.Font("Quicksand Book", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Departments.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Departments.Location = new System.Drawing.Point(0, 200);
            this.btn_Departments.Name = "btn_Departments";
            this.btn_Departments.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Departments.Size = new System.Drawing.Size(201, 40);
            this.btn_Departments.TabIndex = 3;
            this.btn_Departments.Text = "Departments";
            this.btn_Departments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Departments.UseVisualStyleBackColor = true;
            this.btn_Departments.Click += new System.EventHandler(this.btn_Departments_Click);
            // 
            // panelProducts
            // 
            this.panelProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(112)))), ((int)(((byte)(143)))));
            this.panelProducts.Controls.Add(this.btn_Find);
            this.panelProducts.Controls.Add(this.btnAdd);
            this.panelProducts.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelProducts.Location = new System.Drawing.Point(0, 140);
            this.panelProducts.Name = "panelProducts";
            this.panelProducts.Size = new System.Drawing.Size(201, 60);
            this.panelProducts.TabIndex = 2;
            // 
            // btn_Find
            // 
            this.btn_Find.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(209)))), ((int)(((byte)(232)))));
            this.btn_Find.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Find.FlatAppearance.BorderSize = 0;
            this.btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Find.Font = new System.Drawing.Font("Quicksand Book", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Find.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Find.Location = new System.Drawing.Point(0, 30);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Find.Size = new System.Drawing.Size(201, 30);
            this.btn_Find.TabIndex = 1;
            this.btn_Find.Text = "Find";
            this.btn_Find.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Find.UseVisualStyleBackColor = false;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(209)))), ((int)(((byte)(232)))));
            this.btnAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdd.Location = new System.Drawing.Point(0, 0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btnAdd.Size = new System.Drawing.Size(201, 30);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add/Delete";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnProducts
            // 
            this.btnProducts.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProducts.FlatAppearance.BorderSize = 0;
            this.btnProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProducts.Font = new System.Drawing.Font("Quicksand Book", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProducts.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnProducts.Location = new System.Drawing.Point(0, 100);
            this.btnProducts.Name = "btnProducts";
            this.btnProducts.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnProducts.Size = new System.Drawing.Size(201, 40);
            this.btnProducts.TabIndex = 1;
            this.btnProducts.Text = "Products";
            this.btnProducts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProducts.UseVisualStyleBackColor = true;
            this.btnProducts.Click += new System.EventHandler(this.btnProducts_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(209)))), ((int)(((byte)(232)))));
            this.panelLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelLogo.BackgroundImage")));
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panelLogo.ContextMenuStrip = this.contextMenuStrip2;
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(201, 100);
            this.panelLogo.TabIndex = 0;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colorToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(104, 26);
            // 
            // colorToolStripMenuItem1
            // 
            this.colorToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundToolStripMenuItem1});
            this.colorToolStripMenuItem1.Name = "colorToolStripMenuItem1";
            this.colorToolStripMenuItem1.Size = new System.Drawing.Size(103, 22);
            this.colorToolStripMenuItem1.Text = "Color";
            // 
            // backgroundToolStripMenuItem1
            // 
            this.backgroundToolStripMenuItem1.Name = "backgroundToolStripMenuItem1";
            this.backgroundToolStripMenuItem1.Size = new System.Drawing.Size(138, 22);
            this.backgroundToolStripMenuItem1.Text = "Background";
            this.backgroundToolStripMenuItem1.Click += new System.EventHandler(this.backgroundToolStripMenuItem1_Click);
            // 
            // panelFooter
            // 
            this.panelFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(44)))), ((int)(((byte)(87)))));
            this.panelFooter.ContextMenuStrip = this.contextMenuStrip1;
            this.panelFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelFooter.Location = new System.Drawing.Point(201, 379);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.Size = new System.Drawing.Size(599, 100);
            this.panelFooter.TabIndex = 1;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colorToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(104, 26);
            // 
            // colorToolStripMenuItem
            // 
            this.colorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundToolStripMenuItem,
            this.foregroundToolStripMenuItem});
            this.colorToolStripMenuItem.Name = "colorToolStripMenuItem";
            this.colorToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.colorToolStripMenuItem.Text = "Color";
            // 
            // backgroundToolStripMenuItem
            // 
            this.backgroundToolStripMenuItem.Name = "backgroundToolStripMenuItem";
            this.backgroundToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.backgroundToolStripMenuItem.Text = "Background";
            this.backgroundToolStripMenuItem.Click += new System.EventHandler(this.backgroundToolStripMenuItem_Click);
            // 
            // foregroundToolStripMenuItem
            // 
            this.foregroundToolStripMenuItem.Name = "foregroundToolStripMenuItem";
            this.foregroundToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.foregroundToolStripMenuItem.Text = "Foreground";
            this.foregroundToolStripMenuItem.Click += new System.EventHandler(this.foregroundToolStripMenuItem_Click);
            // 
            // panelPrincipal
            // 
            this.panelPrincipal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(44)))), ((int)(((byte)(87)))));
            this.panelPrincipal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panelPrincipal.ContextMenuStrip = this.contextMenuStrip1;
            this.panelPrincipal.Controls.Add(this.label1);
            this.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPrincipal.Location = new System.Drawing.Point(201, 0);
            this.panelPrincipal.Name = "panelPrincipal";
            this.panelPrincipal.Size = new System.Drawing.Size(599, 379);
            this.panelPrincipal.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Quicksand Bold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(156, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 66);
            this.label1.TabIndex = 0;
            this.label1.Text = "Shop Management \r\nSystem";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Menu1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 479);
            this.Controls.Add(this.panelPrincipal);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panelMenu);
            this.Name = "Menu1";
            this.Text = "Shop Manangement System";
            this.panelMenu.ResumeLayout(false);
            this.panel_Departments.ResumeLayout(false);
            this.panelProducts.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.panelPrincipal.ResumeLayout(false);
            this.panelPrincipal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btn_Departments;
        private System.Windows.Forms.Panel panelProducts;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnProducts;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panel_Departments;
        private System.Windows.Forms.Button btn_Food;
        private System.Windows.Forms.Button btn_Electronics;
        private System.Windows.Forms.Button btn_Cleaning;
        private System.Windows.Forms.Button btn_Buy;
        private System.Windows.Forms.Button btn_Needs;
        private System.Windows.Forms.Button btn_Graphic;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.Panel panelPrincipal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem colorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem foregroundToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem colorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem backgroundToolStripMenuItem1;
    }
}