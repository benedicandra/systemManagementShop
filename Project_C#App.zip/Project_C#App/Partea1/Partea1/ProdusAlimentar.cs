﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Partea1
{
    public class ProdusAlimentar:Produs,ICloneable,IComparable,Itva
    {
        public ProdusAlimentar() : base()
        {
            
        }

        public ProdusAlimentar(int cod, string denumire, double stoc, double pret, int[]rec)
            : base(cod, denumire, stoc, pret,rec)
        {
           
        }

        public ProdusAlimentar(int cod, string denumire, double stoc, double pret) 
            : base(cod, denumire, stoc, pret)
        {
            
        }

        public ProdusAlimentar(string denumire, double stoc, double pret)
            : base(denumire, stoc, pret)
        {

        }
        
        public double CalcTVA()
        {
            double pretCuTVA = base.Pret;
            pretCuTVA = 1.1 * pretCuTVA;
            return pretCuTVA;
        }
    }
}
