﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Partea1
{
    public partial class Buy : Form
    {
        string connString;
        List<Produs> listaCumparaturi = new List<Produs>();
        public Buy()
        {
            connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Products.accdb";
            InitializeComponent();
        }

        //WRITE THE BILL IN A TEXT FILE
        private void writeBillHeader()
        {
            System.IO.File.WriteAllText("bill.txt", string.Empty);
            using (StreamWriter sw = File.AppendText("bill.txt"))
            {
                sw.WriteLine("                             MEGA ANDRA SRL                   ");
                sw.WriteLine("                      Str.1 Decembrie 1918, no. 18");
                sw.WriteLine();
                sw.WriteLine("                                RECEIPT                                   ");
                sw.WriteLine();
                sw.WriteLine("Product\t" + "Quantity\t" + "Price/Unit  " + " Value\t" + "Value");
                sw.WriteLine("Name\t" + "\t\t" + "\t" + "with VAT\t");
                sw.WriteLine("---------------------------------------------------------------------------------");
            }
        }

        private void writeBillBody()
        {
            StreamWriter sw = File.AppendText("bill.txt");
            foreach (Produs p in listaCumparaturi)
            {
                sw.WriteLine(p.DenumireProdus + "\t" + p.Stoc + "\t" + p.Pret + "\t" + p.Pret * p.Stoc + "\t" + p.CalcTVA() * p.Stoc);

            }
            sw.Close();

        }

        private void writeBillFooter()
        {
            double sum = 0;
            double sumVAT = 0;
            using (StreamWriter sw = File.AppendText("bill.txt"))
            {
                foreach (Produs p in listaCumparaturi)
                {
                    sum += p.CalcTVA() * p.Stoc;
                    sumVAT += (p.CalcTVA() - p.Pret) * p.Stoc;
                }
                sw.WriteLine("-----------------------------------------------------------------------------------");
                sw.WriteLine("TOTAL : " + sum);
                sw.WriteLine("Total VAT : " + sumVAT);
                sw.WriteLine();
                sw.WriteLine("Cashier : Andra Benedic");
                sw.WriteLine("Date : " + System.DateTime.Now.ToString());
                sw.WriteLine();
                sw.WriteLine("\tThank you for coming! Have a nice day!");

            }
        }

        //SEARCH BUTTO FROM DB
        private void button1_Click(object sender, EventArgs e)
        {
            tbStatus.Clear();
            tbPrice.Clear();
            tbQuantity.Clear();

            OleDbConnection conexiune = new OleDbConnection(connString);
            if (cbDepartment.Text == "")
                errorProvider1.SetError(cbDepartment, "Choose department!");
            else
                try
                {
                    if (cbDepartment.Text == "Cleaning")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "SELECT * FROM ProductsCleaning WHERE Name='" + tbSearch.Text + "'";

                            OleDbDataReader reader = comanda.ExecuteReader();

                            while (reader.Read())
                            {

                                tbPrice.Text = reader["Price"].ToString();
                                tbQuantity.Text = reader["Quantity"].ToString();

                                if (Convert.ToInt32(reader["Quantity"]) > 0)
                                    tbStatus.Text = "Available";
                                else
                                    tbStatus.Text = "Unavailable";

                            }
                            if (tbPrice.Text == "")
                                tbStatus.Text = "Unavailable";

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                    else if (cbDepartment.Text == "Electronics")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "SELECT * FROM ProductsElectronics WHERE Name='" + tbSearch.Text + "'";

                            OleDbDataReader reader = comanda.ExecuteReader();

                            while (reader.Read())
                            {

                                tbPrice.Text = reader["Price"].ToString();
                                tbQuantity.Text = reader["Quantity"].ToString();

                                if (Convert.ToInt32(reader["Quantity"]) > 0)
                                    tbStatus.Text = "Available";
                                else
                                    tbStatus.Text = "Unavailable";

                            }

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                    else if (cbDepartment.Text == "Food")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "SELECT * FROM ProductsFood WHERE Name='" + tbSearch.Text + "'";

                            OleDbDataReader reader = comanda.ExecuteReader();

                            while (reader.Read())
                            {

                                tbPrice.Text = reader["Price"].ToString();
                                tbQuantity.Text = reader["Quantity"].ToString();

                                if (Convert.ToInt32(reader["Quantity"]) > 0)
                                    tbStatus.Text = "Available";
                                else
                                    tbStatus.Text = "Unavailable";

                            }

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
        }

        //ADD NEW PRODUCT TO BILL BUTTON, UPDATE DB, ADD TO LIST
        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection conexiune = new OleDbConnection(connString);

            if (tbQR.Text == "")
                errorProvider1.SetError(tbQR, "Enter quantity required!");
            else
                if (tbSearch.Text == "")
                errorProvider1.SetError(tbSearch, "Enter the product name first!");
            else
                if (tbStatus.Text == "Unavailable")
                MessageBox.Show("The product is not available.");
            else
                try
                {
                    if (cbDepartment.Text == "Cleaning")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;

                            double remainQuantity = Convert.ToInt32(tbQuantity.Text) - Convert.ToInt32(tbQR.Text);
                            comanda.CommandText = "UPDATE ProductsCleaning SET Quantity='" + remainQuantity + "' WHERE Name='" + tbSearch.Text + "'";

                            comanda.ExecuteNonQuery();

                            string denumire = tbSearch.Text;
                            double cantitate = Convert.ToDouble(tbQR.Text);
                            double pret = Convert.ToDouble(tbPrice.Text);

                            ProdusCuratare p = new ProdusCuratare(denumire, pret, cantitate);
                            listaCumparaturi.Add(p);

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                    else if (cbDepartment.Text == "Electronics")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;

                            double remainQuantity = Convert.ToInt32(tbQuantity.Text) - Convert.ToInt32(tbQR.Text);
                            comanda.CommandText = "UPDATE ProductsElectronics SET Quantity='" + remainQuantity + "' WHERE Name='" + tbSearch.Text + "'";

                            comanda.ExecuteNonQuery();

                            string denumire = tbSearch.Text;
                            double cantitate = Convert.ToDouble(tbQR.Text);
                            double pret = Convert.ToDouble(tbPrice.Text);

                            ProdusCuratare p = new ProdusCuratare(denumire, pret, cantitate);
                            listaCumparaturi.Add(p);


                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                    else if (cbDepartment.Text == "Food")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;

                            double remainQuantity = Convert.ToInt32(tbQuantity.Text) - Convert.ToInt32(tbQR.Text);
                            comanda.CommandText = "UPDATE ProductsFood SET Quantity='" + remainQuantity + "' WHERE Name='" + tbSearch.Text + "'";

                            comanda.ExecuteNonQuery();

                            string denumire = tbSearch.Text;
                            double cantitate = Convert.ToDouble(tbQR.Text);
                            double pret = Convert.ToDouble(tbPrice.Text);

                            ProdusCuratare p = new ProdusCuratare(denumire, pret, cantitate);
                            listaCumparaturi.Add(p);


                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    tbPrice.Clear();
                    tbQuantity.Clear();
                    tbSearch.Clear();
                    tbStatus.Clear();
                    tbQR.Clear();
                    errorProvider1.Clear();
                }


        }

        private void cbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbPrice.Clear();
            tbQuantity.Clear();
            tbSearch.Clear();
            tbStatus.Clear();
            tbQR.Clear();
        }

        //DISPLAY THE BILL 
        private void button3_Click(object sender, EventArgs e)
        {
            writeBillHeader();
            writeBillBody();
            writeBillFooter();

            StreamReader sr = new StreamReader("bill.txt");
            string s = sr.ReadToEnd();
            richTextBox1.Text = s;
            sr.Close();
        }
    }
}
