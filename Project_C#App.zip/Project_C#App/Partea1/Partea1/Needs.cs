﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Partea1
{
    public partial class Needs : Form

    {
        string connString;
        int y = 30;
        public Needs()
        {
            InitializeComponent();
            connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Products.accdb";
        }
        
        //WRITE LIST OF NEEDS IN LISTVIEW FROM FILE
        private void cbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();
                try
                {
                    if (cbDepartment.Text == "Cleaning")
                    {
                        using (StreamReader sr = new StreamReader("CleaningToBuy.txt"))
                        {
                            string linie = null;
                            while ((linie = sr.ReadLine()) != null)
                            {
                                try
                                {
                                    string denumire = linie.Split(' ')[0];
                                    string stoc = linie.Split(' ')[1];

                                    ListViewItem itm = new ListViewItem(denumire);
                                    itm.SubItems.Add(stoc);

                                    listView1.Items.Add(itm);
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }

                            }

                            sr.Close();
                        }

                    }
                    else if (cbDepartment.Text == "Electronics")
                    {
                        using (StreamReader sr = new StreamReader("ElectronicsToBuy.txt"))
                        {
                            string linie = null;
                            while ((linie = sr.ReadLine()) != null)
                            {
                                try
                                {
                                    string denumire = linie.Split(' ')[0];
                                    string stoc = linie.Split(' ')[1];

                                    ListViewItem itm = new ListViewItem(denumire);
                                    itm.SubItems.Add(stoc);

                                    listView1.Items.Add(itm);
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                            }
                            sr.Close();
                        }
                    }
                    else if (cbDepartment.Text == "Food")
                    {
                        using (StreamReader sr = new StreamReader("FoodToBuy.txt"))
                        {
                            string linie = null;
                            while ((linie = sr.ReadLine()) != null)
                            {
                                try
                                {
                                    string denumire = linie.Split(' ')[0];
                                    string stoc = linie.Split(' ')[1];

                                    ListViewItem itm = new ListViewItem(denumire);
                                    itm.SubItems.Add(stoc);

                                    listView1.Items.Add(itm);
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                            }
                            sr.Close();
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

        }

        
        //SEARCH FROM DB BUTTON
        private void button1_Click(object sender, EventArgs e)
        {
            tbStatus.Clear();
            tbPrice.Clear();
            tbQuantity.Clear();

            OleDbConnection conexiune = new OleDbConnection(connString);
            if (cbDepartment.Text == "")
                errorProvider1.SetError(cbDepartment, "Choose department!");
            else
                if (tbSearch.Text == "")
                errorProvider1.SetError(tbSearch, "Enter the product you are looking for!");
            try
            {
                if (cbDepartment.Text == "Cleaning")
                {
                    try
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "SELECT * FROM ProductsCleaning WHERE Name='" + tbSearch.Text + "'";

                        OleDbDataReader reader = comanda.ExecuteReader();

                        while (reader.Read())
                        {

                            tbPrice.Text = reader["Price"].ToString();
                            tbQuantity.Text = reader["Quantity"].ToString();

                            if (Convert.ToInt32(reader["Quantity"]) > 0)
                                tbStatus.Text = "Available";
                            else
                                tbStatus.Text = "Unavailable";

                        }
                        if(tbPrice.Text=="")
                                tbStatus.Text = "Unavailable";

                        }
                    catch (OleDbException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conexiune.Close();
                    }
                }
                else if (cbDepartment.Text == "Electronics")
                {
                    try
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "SELECT * FROM ProductsElectronics WHERE Name='" + tbSearch.Text + "'";

                        OleDbDataReader reader = comanda.ExecuteReader();

                        while (reader.Read())
                        {

                            tbPrice.Text = reader["Price"].ToString();
                            tbQuantity.Text = reader["Quantity"].ToString();

                            if (Convert.ToInt32(reader["Quantity"]) > 0)
                                tbStatus.Text = "Available";
                            else
                                tbStatus.Text = "Unavailable";

                        }

                    }
                    catch (OleDbException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conexiune.Close();
                    }
                }
                else if (cbDepartment.Text == "Food")
                {
                    try
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "SELECT * FROM ProductsFood WHERE Name='" + tbSearch.Text + "'";

                        OleDbDataReader reader = comanda.ExecuteReader();

                        while (reader.Read())
                        {

                            tbPrice.Text = reader["Price"].ToString();
                            tbQuantity.Text = reader["Quantity"].ToString();

                            if (Convert.ToInt32(reader["Quantity"]) > 0)
                                tbStatus.Text = "Available";
                            else
                                tbStatus.Text = "Unavailable";

                        }

                    }
                    catch (OleDbException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conexiune.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //SAVE LIST OF NEEDS IN FILE
        private void writeListInFile()
        {
            if (cbDepartment.Text == "Cleaning")
            {
                StreamWriter sw = new StreamWriter("CleaningToBuy.txt");
                foreach (ListViewItem item in listView1.Items)
                {
                    sw.WriteLine(item.SubItems[0].Text + " " + item.SubItems[1].Text);
                }

                sw.Close();
            }
            else if (cbDepartment.Text == "Electronics")
            {
                StreamWriter sw = new StreamWriter("ElectronicsToBuy.txt");
                foreach (ListViewItem item in listView1.Items)
                {
                    sw.WriteLine(item.SubItems[0].Text + " " + item.SubItems[1].Text);
                }

                sw.Close();
            }
            else if (cbDepartment.Text == "Food")
            {
                StreamWriter sw = new StreamWriter("FoodToBuy.txt");
                foreach (ListViewItem item in listView1.Items)
                {
                    sw.WriteLine(item.SubItems[0].Text + " " + item.SubItems[1].Text);
                }

                sw.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            writeListInFile();
            MessageBox.Show("Changes have been saved successfully!");
        }

        //DELETE ITEM FROM LIST
        private void button3_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.Items)
                if (item.Checked)
                    item.Remove();
        }


        //DRAG AND DROP 
        //UNAVAILABLE PRODUCTS TO LIST OF NEEDS
        
        private void tbSearch_MouseDown(object sender, MouseEventArgs e)
        {
            tbSearch.DoDragDrop(tbSearch.Text, DragDropEffects.Move);

        }
        
        private void listView1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
            
            //tbSearch.Clear();
            //tbQuantity.Clear();
        }

        private void listView1_DragDrop(object sender, DragEventArgs e)
        {
            string text = e.Data.GetData(typeof(string)).ToString();
            ListViewItem item = new ListViewItem(text);
            item.SubItems.Add(tbQuantity.Text);
            listView1.Items.Add(item);

            tbSearch.Clear();
            tbStatus.Clear();
            tbPrice.Clear();
            tbQuantity.Clear();
        }

        //VALIDATION
        private void tbQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) &&
               !char.IsControl(e.KeyChar))
                e.Handled = true;
        }
    }
}
