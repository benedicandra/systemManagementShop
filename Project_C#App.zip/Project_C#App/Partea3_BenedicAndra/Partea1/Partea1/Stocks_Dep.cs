﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Partea1
{
    public partial class Stocks_Dep : Form
    {
        double[] nrProduse = new double[3];

        const int marg = 10;
        const int nrDep = 3;
        List<ProdusAlimentar> produseAl = new List<ProdusAlimentar>();
        List<ProdusCuratare> produseCl = new List<ProdusCuratare>();
        List<ProdusElectronic> produseEl = new List<ProdusElectronic>();
        Raion rAlimente = new Raion("   Food", new List<Object>());
        Raion rElectronice = new Raion("Electronics", new List<Object>());
        Raion rCuratare = new Raion("Cleaning", new List<Object>());
        List<Raion> listaRaioane = new List<Raion>();

        string connString;

        Color culoare = Color.Aquamarine;
        Font font = new Font(FontFamily.GenericSansSerif, 12, FontStyle.Bold);
        public Stocks_Dep()
        {
            connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Products.accdb";
            InitializeComponent();
        }

        //LOAD DATA FROM DB
        public void loadData()
        {
            OleDbConnection conexiune = new OleDbConnection(connString);


            try
            {
                conexiune.Open();
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = conexiune;
                comanda.CommandText = "SELECT * FROM ProductsCleaning";

                OleDbDataReader reader = comanda.ExecuteReader();

                while (reader.Read())
                {

                    //formez obiecte de tip produs si le adaug in lista
                    int cod = Convert.ToInt32(reader["Id"].ToString());
                    string denumire = reader["Name"].ToString();
                    double pret = Convert.ToDouble(reader["Price"].ToString());
                    double stoc = Convert.ToDouble(reader["Quantity"].ToString());


                    ProdusCuratare pa = new ProdusCuratare(cod, denumire, stoc, pret);

                    produseCl.Add(pa);
                    rCuratare = rCuratare + pa;
                }
                reader.Close();

            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexiune.Close();

            }

            try
            {
                conexiune.Open();
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = conexiune;
                comanda.CommandText = "SELECT * FROM ProductsElectronics";

                OleDbDataReader reader = comanda.ExecuteReader();

                while (reader.Read())
                {

                    //formez obiecte de tip produs si le adaug in lista
                    int cod = Convert.ToInt32(reader["Id"].ToString());
                    string denumire = reader["Name"].ToString();
                    double pret = Convert.ToDouble(reader["Price"].ToString());
                    double stoc = Convert.ToDouble(reader["Quantity"].ToString());

                    ProdusElectronic pa = new ProdusElectronic(cod, denumire, stoc, pret);

                    produseEl.Add(pa);
                    rElectronice = rElectronice + pa;

                }
                reader.Close();

            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexiune.Close();
            }

            try
            {
                conexiune.Open();
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = conexiune;
                comanda.CommandText = "SELECT * FROM ProductsFood";

                OleDbDataReader reader = comanda.ExecuteReader();

                while (reader.Read())
                {

                    //formez obiecte de tip produs si le adaug in lista
                    int cod = Convert.ToInt32(reader["Id"].ToString());
                    string denumire = reader["Name"].ToString();
                    double pret = Convert.ToDouble(reader["Price"].ToString());
                    double stoc = Convert.ToDouble(reader["Quantity"].ToString());

                    ProdusAlimentar pa = new ProdusAlimentar(cod, denumire, stoc, pret);

                    produseAl.Add(pa);
                    rAlimente = rAlimente + pa;

                }
                reader.Close();

            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexiune.Close();
            }
        }
        
        private void loadDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            loadData();
            
            double stocTotalAl = 0;
            foreach(ProdusAlimentar pa in produseAl)
            {
                stocTotalAl += pa.Stoc;
            }

            double stocTotalEl = 0;
            foreach (ProdusElectronic p in produseEl)
            {
                stocTotalEl += p.Stoc;
            }

            double stocTotalCl = 0;
            foreach (ProdusCuratare p in produseCl)
            {
                stocTotalCl += p.Stoc;
            }
            nrProduse[0]= stocTotalAl;
            nrProduse[1] = stocTotalEl;
            nrProduse[2] = stocTotalCl;

            StreamWriter sw = new StreamWriter("stocks.txt");
            for (int i = 0; i < nrDep; i++)
            {
                sw.WriteLine(nrProduse[i]);

            }
            sw.Close();
            //MessageBox.Show("Data loaded!");
            //Invalidate();
            panel1.Invalidate();
        }

        
        //PAINT THE GRAPHIC
        private void Statistics_Dep_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rec = new Rectangle(this.ClientRectangle.X + marg, this.ClientRectangle.Y + 8 * marg,
                    this.ClientRectangle.Width - 2 * marg, this.ClientRectangle.Height - 9 * marg);
            Pen pen = new Pen(Color.DarkGray, 2);
            g.DrawRectangle(pen, rec);

            double latime = rec.Width / nrDep / 3;
            double distanta = (rec.Width - nrDep * latime) / (nrDep + 1);
            double vMax = nrProduse.Max();

            listaRaioane.Add(rAlimente);
            listaRaioane.Add(rElectronice);
            listaRaioane.Add(rCuratare);

            Brush br = new SolidBrush(culoare);

            Rectangle[] recs = new Rectangle[nrDep];
            for (int i = 0; i < nrDep; i++)
            {
                recs[i] = new Rectangle((int)(rec.Location.X + (i + 1) * distanta + i * latime),
                  (int)(rec.Location.Y + rec.Height - nrProduse[i] / vMax * rec.Height),
                  (int)latime,
                  (int)(nrProduse[i] / vMax * rec.Height));
                g.DrawString(listaRaioane[i].DenumireRaion, font, br, new Point((int)(recs[i].Location.X),
                    (int)(recs[i].Location.Y - 2 * font.Height)));
                g.DrawString(nrProduse[i].ToString(), font, br, new Point((int)(recs[i].Location.X + latime / 3),
                    (int)(recs[i].Location.Y - font.Height)));


            }
            g.FillRectangles(br, recs);

            /*for (int i = 0; i < nrDep - 1; i++)
                g.DrawLine(pen, new Point((int)(recs[i].Location.X + latime / 2),
                    (int)(recs[i].Location.Y)), new Point((int)(recs[i + 1].Location.X + latime / 2),
                    (int)(recs[i + 1].Location.Y)));*/
        }

        //SAVE THE GRAPHIC IN A BITMAP
        private void save(Control c, string denumire)
        {
            Bitmap img = new Bitmap(c.Width, c.Height);
            c.DrawToBitmap(img, new Rectangle(c.ClientRectangle.X, c.ClientRectangle.Y,
                c.ClientRectangle.Width, c.ClientRectangle.Height));
            img.Save(denumire);
            img.Dispose();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //save(this, "graphic.bmp");
            save(panel1, "graphic.bmp");
            MessageBox.Show("Graphic saved!");
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rec = new Rectangle(panel1.ClientRectangle.X + marg, panel1.ClientRectangle.Y + 4 * marg,
                    panel1.ClientRectangle.Width - 2 * marg, panel1.ClientRectangle.Height - 5 * marg);
            Pen pen = new Pen(Color.DarkGray, 2);
            g.DrawRectangle(pen, rec);

            double latime = rec.Width / nrDep / 3;
            double distanta = (rec.Width - nrDep * latime) / (nrDep + 1);
            double vMax = nrProduse.Max();

            listaRaioane.Add(rAlimente);
            listaRaioane.Add(rElectronice);
            listaRaioane.Add(rCuratare);

            Brush br = new SolidBrush(culoare);

            Rectangle[] recs = new Rectangle[nrDep];
            for (int i = 0; i < nrDep; i++)
            {
                recs[i] = new Rectangle((int)(rec.Location.X + (i + 1) * distanta + i * latime),
                  (int)(rec.Location.Y + rec.Height - nrProduse[i] / vMax * rec.Height),
                  (int)latime,
                  (int)(nrProduse[i] / vMax * rec.Height));
                g.DrawString(listaRaioane[i].DenumireRaion, font, br, new Point((int)(recs[i].Location.X),
                     (int)(recs[i].Location.Y - 2 * font.Height)));
                g.DrawString(nrProduse[i].ToString(), font, br, new Point((int)(recs[i].Location.X + latime / 3),
                    (int)(recs[i].Location.Y - font.Height)));

            }
            g.FillRectangles(br, recs);

        }

        //PRINT PREVIEW
        private void pdPrint(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rec = new Rectangle(e.PageBounds.X + marg, e.PageBounds.Y + 4 * marg,
                    e.PageBounds.Width - 2 * marg, e.PageBounds.Height - 5 * marg);
            Pen pen = new Pen(Color.DarkGray, 2);
            g.DrawRectangle(pen, rec);

            double latime = rec.Width / nrDep / 3;
            double distanta = (rec.Width - nrDep * latime) / (nrDep + 1);
            double vMax = nrProduse.Max();

            listaRaioane.Add(rAlimente);
            listaRaioane.Add(rElectronice);
            listaRaioane.Add(rCuratare);

            Brush br = new SolidBrush(culoare);

            Rectangle[] recs = new Rectangle[nrDep];
            for (int i = 0; i < nrDep; i++)
            {
                recs[i] = new Rectangle((int)(rec.Location.X + (i + 1) * distanta + i * latime),
                  (int)(rec.Location.Y + rec.Height - nrProduse[i] / vMax * rec.Height),
                  (int)latime,
                  (int)(nrProduse[i] / vMax * rec.Height));
                g.DrawString(listaRaioane[i].DenumireRaion, font, br, new Point((int)(recs[i].Location.X),
                    (int)(recs[i].Location.Y - 2*font.Height)));
                g.DrawString(nrProduse[i].ToString(), font, br, new Point((int)(recs[i].Location.X + latime / 3),
                    (int)(recs[i].Location.Y - font.Height)));
                

            }
            g.FillRectangles(br, recs);
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(pdPrint);
            PrintPreviewDialog dlg = new PrintPreviewDialog();
            dlg.Document = pd;
            dlg.ShowDialog();
        }
    }

}
