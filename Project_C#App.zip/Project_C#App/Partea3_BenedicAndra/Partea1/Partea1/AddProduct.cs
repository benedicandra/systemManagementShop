﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Partea1
{
    public partial class AddProduct : Form
    {
        List<ProdusAlimentar> listaAlim = new List<ProdusAlimentar>();
        List<ProdusElectronic> listaElectr = new List<ProdusElectronic>();
        List<ProdusCuratare> listaCurat = new List<ProdusCuratare>();
        Raion rAlimente = new Raion("Food", new List<Object>());
        Raion rElectronice = new Raion("Electronics", new List<Object>());
        Raion rCuratare = new Raion("Cleaning", new List<Object>());

        string connString;

        public AddProduct()
        {
            
            InitializeComponent();
            connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Products.accdb";
        }

        public void addToListView(Produs p)
        {
            ListViewItem itm = new ListViewItem(p.CodProdus.ToString());
            itm.SubItems.Add(p.DenumireProdus);
            itm.SubItems.Add(p.Pret.ToString());
            itm.SubItems.Add(p.Stoc.ToString());

            if (p.Stoc > 0)
            {
                itm.SubItems.Add("Available");
            }
            else
            {
                itm.SubItems.Add("Unavailable");
            }

            listView1.Items.Add(itm);
        }

        public void writeListViewFood()
        {
            foreach (ProdusAlimentar p in listaAlim)
            {
                addToListView(p);
            }
        }

        public void writeListViewCleaning()
        {
            foreach (ProdusCuratare pc in listaCurat)
            {
                addToListView(pc);
            }
        }

        public void writeListViewElectronics()
        {
            foreach (ProdusElectronic pe in listaElectr)
            {
                addToListView(pe);
            }
        }

        private void ClearData()
        {
            cbDepartment.Text = "";
            tbId.Clear();
            tbName.Clear();
            tbQuantity.Clear();
            tbPrice.Clear();

            tbVAT.Clear();
            tbReviews.Clear();
            errorProvider1.Clear();
        }

        //READ DATA FROM DB, ADD TO LISVIEW
        private void loadDataDB()
        {
            OleDbConnection conexiune = new OleDbConnection(connString);

            try
            {
                if (cbDepartment.Text == "Cleaning")
                {
                    try
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "SELECT * FROM ProductsCleaning";

                        OleDbDataReader reader = comanda.ExecuteReader();

                        while (reader.Read())
                        {
                            //afisarea in listview 
                            ListViewItem itm = new ListViewItem(reader["Id"].ToString());
                            itm.SubItems.Add(reader["Name"].ToString());
                            itm.SubItems.Add(reader["Price"].ToString());
                            itm.SubItems.Add(reader["Quantity"].ToString());


                            if (Convert.ToInt32(reader["Quantity"] )> 0)
                                itm.SubItems.Add("Available");
                            else
                                itm.SubItems.Add("Unavailable");

                            listView1.Items.Add(itm);
                            
                            //formez obiecte de tip produs si le adaug in lista
                            int cod = Convert.ToInt32(reader["Id"].ToString());
                            string denumire = reader["Name"].ToString();
                            double pret = Convert.ToDouble(reader["Price"].ToString());
                            double stoc = Convert.ToDouble(reader["Quantity"].ToString());
                            

                            ProdusCuratare pa = new ProdusCuratare(cod, denumire, stoc, pret);

                            listaCurat.Add(pa);
                            rCuratare = rCuratare + pa;
                        }
                        reader.Close();

                    }
                    catch (OleDbException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conexiune.Close();
                        
                    }
                }
                else
                    if (cbDepartment.Text == "Electronics")
                {
                    try
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "SELECT * FROM ProductsElectronics";

                        OleDbDataReader reader = comanda.ExecuteReader();

                        while (reader.Read())
                        {
                            //afisarea in listview 
                            ListViewItem itm = new ListViewItem(reader["Id"].ToString());
                            itm.SubItems.Add(reader["Name"].ToString());
                            itm.SubItems.Add(reader["Price"].ToString());
                            itm.SubItems.Add(reader["Quantity"].ToString());


                            if (Convert.ToInt32(reader["Quantity"]) > 0)
                                itm.SubItems.Add("Available");
                            else
                                itm.SubItems.Add("Unavailable");

                            listView1.Items.Add(itm);

                            //formez obiecte de tip produs si le adaug in lista
                            int cod = Convert.ToInt32(reader["Id"].ToString());
                            string denumire = reader["Name"].ToString();
                            double pret = Convert.ToDouble(reader["Price"].ToString());
                            double stoc = Convert.ToDouble(reader["Quantity"].ToString());

                            ProdusElectronic pa = new ProdusElectronic(cod, denumire, stoc, pret);

                            listaElectr.Add(pa);
                            rElectronice = rElectronice + pa;

                        }
                        reader.Close();

                    }
                    catch (OleDbException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conexiune.Close();
                    }

                }
                else
                if (cbDepartment.Text == "Food")
                {
                    try
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "SELECT * FROM ProductsFood";

                        OleDbDataReader reader = comanda.ExecuteReader();

                        while (reader.Read())
                        {
                            //afisarea in listview 
                            ListViewItem itm = new ListViewItem(reader["Id"].ToString());
                            itm.SubItems.Add(reader["Name"].ToString());
                            itm.SubItems.Add(reader["Price"].ToString());
                            itm.SubItems.Add(reader["Quantity"].ToString());


                            if (Convert.ToInt32(reader["Quantity"]) > 0)
                                itm.SubItems.Add("Available");
                            else
                                itm.SubItems.Add("Unavailable");

                            listView1.Items.Add(itm);

                            //formez obiecte de tip produs si le adaug in lista
                            int cod = Convert.ToInt32(reader["Id"].ToString());
                            string denumire = reader["Name"].ToString();
                            double pret = Convert.ToDouble(reader["Price"].ToString());
                            double stoc = Convert.ToDouble(reader["Quantity"].ToString());

                            ProdusAlimentar pa = new ProdusAlimentar(cod, denumire, stoc, pret);

                            listaAlim.Add(pa);
                            rAlimente = rAlimente + pa;

                        }
                        reader.Close();

                    }
                    catch (OleDbException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conexiune.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //READ DATA FROM TXT FILE, ADD TO LISVIEW
        private void loadData()
        {
            try
            {
                if (cbDepartment.Text == "Cleaning")
                { 
                    using (StreamReader sr = new StreamReader("cleaning.txt"))
                    {
                        string linie = null;
                        while ((linie = sr.ReadLine()) != null)
                        {
                            try
                            {
                                int cod = Convert.ToInt32(linie.Split(' ')[0]);
                                string denumire = linie.Split(' ')[1];
                                double stoc = Convert.ToDouble(linie.Split(' ')[2]);
                                double pret = Convert.ToDouble(linie.Split(' ')[3]);

                                ProdusCuratare pa = new ProdusCuratare(cod, denumire, stoc, pret);

                                listaCurat.Add(pa);
                                rAlimente = rAlimente + pa;
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }

                        }
                        sr.Close();
                    }
                    writeListViewCleaning();
                    listaCurat.Clear();
                }
                else
                    if (cbDepartment.Text == "Electronics")
                {
                    using (StreamReader sr = new StreamReader("electronics.txt"))
                    {
                        string linie = null;
                        while ((linie = sr.ReadLine()) != null)
                        {
                            try
                            {
                                int cod = Convert.ToInt32(linie.Split(' ')[0]);
                                string denumire = linie.Split(' ')[1];
                                double stoc = Convert.ToDouble(linie.Split(' ')[2]);
                                double pret = Convert.ToDouble(linie.Split(' ')[3]);

                                ProdusElectronic pe = new ProdusElectronic(cod, denumire, stoc, pret);

                                listaElectr.Add(pe);
                                rElectronice = rElectronice + pe;
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }

                        }
                        sr.Close();
                    }
                    writeListViewElectronics();
                    listaElectr.Clear();
                    //foreach (Object o in rElectronice.ListaProduse)
                        //MessageBox.Show(o.ToString()); au fost adugate in lista
                }
                else if (cbDepartment.Text == "Food")
                {
                    using (StreamReader sr = new StreamReader("food.txt"))
                    {
                        string linie = null;
                        while ((linie = sr.ReadLine()) != null)
                        {
                            try
                            {
                                int cod = Convert.ToInt32(linie.Split(' ')[0]);
                                string denumire = linie.Split(' ')[1];
                                double stoc = Convert.ToDouble(linie.Split(' ')[2]);
                                double pret = Convert.ToDouble(linie.Split(' ')[3]);

                                ProdusAlimentar pa = new ProdusAlimentar(cod, denumire, stoc, pret);

                                listaAlim.Add(pa);
                                rAlimente = rAlimente + pa;

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message); 
                            }

                        }
                        sr.Close();
                    }
                    writeListViewFood();
                    listaAlim.Clear();
                } 
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //MessageBox.Show("Data loaded!");
            
        }

        //ADD NEW PRODUCT IN TXT FILE, LIST
        /*private void button1_Click(object sender, EventArgs e)
        {
            if (cbDepartment.Text == "")
                errorProvider1.SetError(cbDepartment, "Enter department!");
            else
                if (tbId.Text == "")
                    errorProvider1.SetError(tbId, "Enter product ID!");
            else
                if (tbName.Text == "")
                    errorProvider1.SetError(tbName, "Enter product name!");
            else
                if (tbQuantity.Text == "")
                    errorProvider1.SetError(tbQuantity, "Enter quantity!");
            else
                if (tbPrice.Text == "")
                    errorProvider1.SetError(tbPrice, "Enter price!");

            else
                if (tbReviews.Text == "")
                    errorProvider1.SetError(tbReviews, "Enter reviews!");
            else
            {
                try
                {
                    string raion = cbDepartment.Text;
                    int cod = Convert.ToInt32(tbId.Text);
                    string denumire = tbName.Text;
                    double stoc = Convert.ToDouble(tbQuantity.Text);
                    double pret = Convert.ToDouble(tbPrice.Text);
                    string[] recenzii = tbReviews.Text.Split(',');
                    int[] recenzii2 = new int[recenzii.Length];
                    for (int i = 0; i < recenzii.Length; i++)
                        recenzii2[i] = Convert.ToInt32(recenzii[i]);



                    if (raion == "Food")
                    {
                        try
                            {
                                ProdusAlimentar pa = new ProdusAlimentar(cod, denumire, stoc, pret, recenzii2);
                                double vat = pa.CalcTVA();
                                tbVAT.Text = vat.ToString();
                                rAlimente = rAlimente + pa;
                            
                                using (StreamWriter w = File.AppendText("food.txt"))
                                {
                                    w.WriteLine(pa.ToString());
                                }
                                MessageBox.Show(pa.ToString());

                            addToListView(pa);

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                            finally
                            {
                                errorProvider1.Clear();
                            }


                    }
                    else
                        if (raion == "Electronics")
                    {
                       try
                            {
                                ProdusElectronic pe = new ProdusElectronic(cod, denumire, stoc, pret, recenzii2);
                                double vat = pe.CalcTVA();
                                tbVAT.Text = vat.ToString();
                            rElectronice = rElectronice + pe;

                                using (StreamWriter w = File.AppendText("electronics.txt"))
                                {
                                    w.WriteLine(pe.ToString());
                                }

                            addToListView(pe);
                            
                            MessageBox.Show(pe.ToString());
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                            finally
                            {
                                errorProvider1.Clear();
                            }


                    }
                    else
                        if (raion == "Cleaning")
                    {
                        try
                            {
                                ProdusCuratare pc = new ProdusCuratare(cod, denumire, stoc, pret, recenzii2);
                                double vat = pc.CalcTVA();
                                tbVAT.Text = vat.ToString();
                                rCuratare = rCuratare + pc;
                                using (StreamWriter w = File.AppendText("cleaning.txt"))
                                {
                                    w.WriteLine(pc.ToString());
                                }

                            addToListView(pc);

                            MessageBox.Show(pc.ToString());
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                            finally
                            {
                                errorProvider1.Clear();
                            }
                    }
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    ClearData();
                }
            }
        }*/


        //VALIDATION

        private void tbId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) &&
                !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void tbQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) &&
                !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void tbPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) &&
                !char.IsControl(e.KeyChar) && e.KeyChar != '.')
                e.Handled = true;
        }

        private void tbReviews_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) &&
                !char.IsControl(e.KeyChar) && e.KeyChar != ',')
                e.Handled = true;
        }

        
        private void cbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            ClearData();
            loadDataDB();
            
            //loadData();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                tbId.Text = listView1.SelectedItems[0].Text;
                tbName.Text = listView1.SelectedItems[0].SubItems[1].Text;
                tbPrice.Text = listView1.SelectedItems[0].SubItems[2].Text;
                tbQuantity.Text = listView1.SelectedItems[0].SubItems[3].Text;
            }
            catch
            {

            }

        }


        //ADD NEW PRODUCT IN DB, TEXT FILE, LIST
        private void button1_Click(object sender, EventArgs e)
        {
            if (cbDepartment.Text == "")
                errorProvider1.SetError(cbDepartment, "Enter department!");
            else
                if (tbId.Text == "")
                errorProvider1.SetError(tbId, "Enter product ID!");
            else
                if (tbName.Text == "")
                errorProvider1.SetError(tbName, "Enter product name!");
            else
                if (tbQuantity.Text == "")
                errorProvider1.SetError(tbQuantity, "Enter quantity!");
            else
                if (tbPrice.Text == "")
                errorProvider1.SetError(tbPrice, "Enter price!");

            else
                if (tbReviews.Text == "")
                errorProvider1.SetError(tbReviews, "Enter reviews!");
            else
            {
                OleDbConnection conexiune = new OleDbConnection(connString);
                try
                {

                    string raion = cbDepartment.Text;
                    int cod = Convert.ToInt32(tbId.Text);
                    string denumire = tbName.Text;
                    double stoc = Convert.ToDouble(tbQuantity.Text);
                    double pret = Convert.ToDouble(tbPrice.Text);
                    string[] recenzii = tbReviews.Text.Split(',');
                    int[] recenzii2 = new int[recenzii.Length];
                    for (int i = 0; i < recenzii.Length; i++)
                        recenzii2[i] = Convert.ToInt32(recenzii[i]);


                    if (raion == "Food")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "INSERT INTO ProductsFood VALUES(?,?,?,?)";

                            comanda.Parameters.Add("Id", OleDbType.Integer).Value = Convert.ToInt32(tbId.Text);
                            comanda.Parameters.Add("Name", OleDbType.Char).Value = tbName.Text;
                            comanda.Parameters.Add("Price", OleDbType.Integer).Value = Convert.ToInt32(tbPrice.Text);
                            comanda.Parameters.Add("Quantity", OleDbType.Integer).Value = Convert.ToInt32(tbQuantity.Text);
                            //comanda.Parameters.Add("Reviews", OleDbType.Integer).Value = recenzii2;

                            comanda.ExecuteNonQuery();

                            ProdusAlimentar pa = new ProdusAlimentar(cod, denumire, stoc, pret, recenzii2);
                            double vat = pa.CalcTVA()- pa.Pret ;
                            tbVAT.Text = vat.ToString();
                            rAlimente = rAlimente + pa;

                            using (StreamWriter w = File.AppendText("food.txt"))
                            {
                                w.WriteLine(pa.ToString());
                                w.Close();
                            }
                            MessageBox.Show("Product "+pa.ToString()+" was succesfully added!");

                            addToListView(pa);
                            



                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            ClearData();
                        }


                    }
                    else
                        if (raion == "Electronics")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "INSERT INTO ProductsElectronics VALUES(?,?,?,?)";

                            comanda.Parameters.Add("Id", OleDbType.Integer).Value = Convert.ToInt32(tbId.Text);
                            comanda.Parameters.Add("Name", OleDbType.Char).Value = tbName.Text;
                            comanda.Parameters.Add("Price", OleDbType.Integer).Value = Convert.ToInt32(tbPrice.Text);
                            comanda.Parameters.Add("Quantity", OleDbType.Integer).Value = Convert.ToInt32(tbQuantity.Text);

                            //comanda.Parameters.Add("Reviews", OleDbType.Integer).Value = recenzii2;

                            comanda.ExecuteNonQuery();

                            ProdusElectronic pe = new ProdusElectronic(cod, denumire, stoc, pret, recenzii2);
                            double vat = pe.CalcTVA()- pe.Pret;
                            tbVAT.Text = vat.ToString();
                            rElectronice = rElectronice + pe;

                            using (StreamWriter w = File.AppendText("electronics.txt"))
                            {
                                w.WriteLine(pe.ToString());
                                w.Close();
                            }

                            addToListView(pe);

                            MessageBox.Show("Product " + pe.ToString() + " was succesfully added!");
                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            ClearData();
                        }

                    }
                    else
                        if (raion == "Cleaning")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "INSERT INTO ProductsCleaning VALUES(?,?,?,?)";

                            comanda.Parameters.Add("Id", OleDbType.Integer).Value = Convert.ToInt32(tbId.Text);
                            comanda.Parameters.Add("Name", OleDbType.Char).Value = tbName.Text;
                            comanda.Parameters.Add("Price", OleDbType.Integer).Value = Convert.ToInt32(tbPrice.Text);
                            comanda.Parameters.Add("Quantity", OleDbType.Integer).Value = Convert.ToInt32(tbQuantity.Text);

                            //comanda.Parameters.Add("Reviews", OleDbType.Integer).Value = recenzii2;

                            comanda.ExecuteNonQuery();

                            ProdusCuratare pc = new ProdusCuratare(cod, denumire, stoc, pret, recenzii2);
                            double vat = pc.CalcTVA() - pc.Pret; ;
                            tbVAT.Text = vat.ToString();
                            rCuratare = rCuratare + pc;
                            using (StreamWriter w = File.AppendText("cleaning.txt"))
                            {
                                w.WriteLine(pc.ToString());
                                w.Close();
                            }

                            addToListView(pc);

                            MessageBox.Show("Product " + pc.ToString() + " was succesfully added!");

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            ClearData();
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    ClearData();
                }
            }
        }

        //DELETE DATA FROM DB, LISTVIEW, LIST  
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.Items)
               
                    if (item.Selected)
                    {
                        item.Remove();
                    }
                    
                
            OleDbConnection conexiune = new OleDbConnection(connString);

            try
            {
                if (cbDepartment.Text == "Cleaning")
                {
                    conexiune.Open();
                    OleDbCommand comanda = new OleDbCommand();
                    comanda.Connection = conexiune;
                    comanda.CommandText = "DELETE FROM ProductsCleaning WHERE Id=" + tbId.Text + "";

                    comanda.ExecuteNonQuery();
                }

                else
                    if (cbDepartment.Text == "Electronics")
                {
                    conexiune.Open();
                    OleDbCommand comanda = new OleDbCommand();
                    comanda.Connection = conexiune;
                    comanda.CommandText = "DELETE FROM ProductsElectronics WHERE Id=" + tbId.Text + "";

                    comanda.ExecuteNonQuery();
                }
                else
                    if (cbDepartment.Text == "Food")
                {
                    conexiune.Open();
                    OleDbCommand comanda = new OleDbCommand();
                    comanda.Connection = conexiune;
                    comanda.CommandText = "DELETE FROM ProductsFood WHERE Id=" + tbId.Text + "";

                    comanda.ExecuteNonQuery();
                }

            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                ClearData();
                conexiune.Close();
            }

        }

        //UPDATE DATA IN DB, LISTVIEW
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                listView1.SelectedItems[0].SubItems[0].Text = tbId.Text;
                listView1.SelectedItems[0].SubItems[1].Text = tbName.Text;
                listView1.SelectedItems[0].SubItems[2].Text = tbPrice.Text;
                listView1.SelectedItems[0].SubItems[3].Text = tbQuantity.Text;

                OleDbConnection conexiune = new OleDbConnection(connString);

                try
                {
                    if (cbDepartment.Text == "Cleaning")
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "UPDATE ProductsCleaning SET Name='" + tbName.Text + "', Quantity='" + tbQuantity.Text + "', Price='" + tbPrice.Text + "' WHERE Id=" + tbId.Text + "";

                        comanda.ExecuteNonQuery();
                        conexiune.Close();

                        MessageBox.Show("The product was succesfully updated!");
                    }

                    else
                        if (cbDepartment.Text == "Electrics")
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "UPDATE ProductsElectronics SET Name='" + tbName.Text + "', Quantity='" + tbQuantity.Text + "', Price='" + tbPrice.Text + "' WHERE Id=" + tbId.Text + "";

                        comanda.ExecuteNonQuery();
                        conexiune.Close();

                        MessageBox.Show("The product was succesfully updated!");
                    }
                    else
                        if (cbDepartment.Text == "Food")
                    {
                        conexiune.Open();
                        OleDbCommand comanda = new OleDbCommand();
                        comanda.Connection = conexiune;
                        comanda.CommandText = "UPDATE ProductsFood SET Name='" + tbName.Text + "', Quantity='" + tbQuantity.Text + "', Price='" + tbPrice.Text + "' WHERE Id=" + tbId.Text + "";

                        comanda.ExecuteNonQuery();
                        conexiune.Close();

                        MessageBox.Show("The product was succesfully updated!");
                    }

                }
                catch (OleDbException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conexiune.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                ClearData();
            }


        }

        //DELETE DATA FROM DB, LISTVIEW, LIST
        private void button3_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.Items)
                if (item.Selected)
                    item.Remove();
                
            OleDbConnection conexiune = new OleDbConnection(connString);

            try
            {
                if (cbDepartment.Text == "Cleaning")
                {
                    conexiune.Open();
                    OleDbCommand comanda = new OleDbCommand();
                    comanda.Connection = conexiune;
                    comanda.CommandText = "DELETE FROM ProductsCleaning WHERE Id=" + tbId.Text + "";

                    comanda.ExecuteNonQuery();

                    MessageBox.Show("The product was succesfully deleted!");
                }

                else
                    if (cbDepartment.Text == "Electronics")
                {
                    conexiune.Open();
                    OleDbCommand comanda = new OleDbCommand();
                    comanda.Connection = conexiune;
                    comanda.CommandText = "DELETE FROM ProductsElectronics WHERE Id=" + tbId.Text + "";

                    comanda.ExecuteNonQuery();

                    MessageBox.Show("The product was succesfully deleted!");
                }
                else
                    if (cbDepartment.Text == "Food")
                {
                    conexiune.Open();
                    OleDbCommand comanda = new OleDbCommand();
                    comanda.Connection = conexiune;
                    comanda.CommandText = "DELETE FROM ProductsFood WHERE Id=" + tbId.Text + "";

                    comanda.ExecuteNonQuery();
                    MessageBox.Show("The product was succesfully deleted!");
                }

            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                ClearData();
                conexiune.Close();
            }

        }

    }
}
