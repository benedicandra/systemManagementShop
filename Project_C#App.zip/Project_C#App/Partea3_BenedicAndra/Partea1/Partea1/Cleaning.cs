﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Data.OleDb;

namespace Partea1
{
    public partial class Cleaning : Form
    {
        string connString;
        List<ProdusCuratare> produseCuratare = new List<ProdusCuratare>();

        public Cleaning()
        {
            InitializeComponent();
            connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Products.accdb";
            //showProducts();
            showProductsDB();
        }

        //DISPLAY DATA FROM DB IN LISTVIEW
        private void showProductsDB()
        {
            OleDbConnection conexiune = new OleDbConnection(connString);
            try
            {
                conexiune.Open();
                //MessageBox.Show("Data base conected!");
                //OleDbCommand comanda = new OleDbCommand("SELECT * FROM Products", conexiune);
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = conexiune;
                comanda.CommandText = "SELECT * FROM ProductsCleaning";

                OleDbDataReader reader = comanda.ExecuteReader();
                while (reader.Read())
                {
                    ListViewItem itm = new ListViewItem(reader["Id"].ToString());
                    itm.SubItems.Add(reader["Name"].ToString());
                    itm.SubItems.Add(reader["Price"].ToString());
                    itm.SubItems.Add(reader["Quantity"].ToString());
                    

                    if (Convert.ToInt32(reader["Quantity"]) > 0)
                        itm.SubItems.Add("Available");
                    else
                        itm.SubItems.Add("Unavailable");

                    listView1.Items.Add(itm);
                }

                comanda.ExecuteNonQuery();
            }
            catch(OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexiune.Close();
            }
        }

        //DISPLAY DATA FROM TEXT FILE IN LISTVIEW
        private void showProducts()
        {
            try
            {
                using (StreamReader sr = new StreamReader("cleaning.txt"))
                {
                    string linie = null;
                    while ((linie = sr.ReadLine()) != null)
                    {
                        try
                        {
                            int cod = Convert.ToInt32(linie.Split(' ')[0]);
                            string denumire = linie.Split(' ')[1];
                            double stoc = Convert.ToDouble(linie.Split(' ')[2]);
                            double pret = Convert.ToDouble(linie.Split(' ')[3]);

                            ProdusCuratare pa = new ProdusCuratare(cod, denumire, stoc, pret);

                            produseCuratare.Add(pa);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                    sr.Close();
                }
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //MessageBox.Show("Data loaded!");
            foreach (ProdusCuratare pa in produseCuratare)
            {
                ListViewItem itm = new ListViewItem(pa.CodProdus.ToString());
                itm.SubItems.Add(pa.DenumireProdus);
                itm.SubItems.Add(pa.Pret.ToString());
                itm.SubItems.Add(pa.Stoc.ToString());

                if (pa.Stoc > 0)
                {
                    itm.SubItems.Add("Available");
                }
                else
                {
                    itm.SubItems.Add("Unavailable");
                }


                listView1.Items.Add(itm);
            }
        }

        //SAVE DATA IN TEXT FILE
        private async void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "(*.txt)|*.txt";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(new FileStream(dlg.FileName, FileMode.Create), Encoding.UTF8);
                {
                    foreach (ListViewItem item in listView1.Items)
                    {
                        await sw.WriteLineAsync(item.SubItems[0].Text + "\t" + item.SubItems[1].Text + "\t" + item.SubItems[2].Text + "\t" + item.SubItems[3].Text + "\t" + item.SubItems[4].Text);

                    }
                    MessageBox.Show("Your data has been succesfully exported!");
                }

                sw.Close();
                //listView1.Clear();
            }
        }

        //SAVE DATA IN XML FILE
        private void button1_Click(object sender, EventArgs e)
        { 

        MemoryStream ms = new MemoryStream();
        XmlTextWriter w = new XmlTextWriter(ms, Encoding.UTF8);
        w.Formatting = Formatting.Indented;
            
            w.WriteStartDocument();
            w.WriteStartElement("Cleaning department");

            foreach (ProdusCuratare pa in produseCuratare)
            {
                w.WriteStartElement(pa.ToString());
                w.WriteEndElement();
            }

            w.WriteEndElement();
            w.WriteEndDocument();

            
            w.Close();

            string str = Encoding.UTF8.GetString(ms.ToArray());
            ms.Close();

            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "(*.xml)|*.xml";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(dlg.FileName);
                sw.WriteLine(str);
                sw.Close();
                MessageBox.Show("Your data has been succesfully exported!");
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //CONTEXT MENU STRIP
        private void backgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                    this.BackColor = cd.Color;

            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                    this.ForeColor = cd.Color;

            }
        }
    }
}
