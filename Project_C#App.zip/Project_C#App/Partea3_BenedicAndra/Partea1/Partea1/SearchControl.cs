﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;

namespace Partea1
{
    public partial class SearchControl : UserControl
    {
        string connString;
        public SearchControl()
        {
            connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Products.accdb";
            InitializeComponent();
        }

        //SEARCH FROM DB BUTTON
        private void button1_Click(object sender, EventArgs e)
        {
            tbStatus.Clear();
            tbPrice.Clear();
            tbQuantity.Clear();

            OleDbConnection conexiune = new OleDbConnection(connString);
            if (cbDepartment.Text == "")
                errorProvider1.SetError(cbDepartment, "Choose department!");
            else
                try
                {
                    if (cbDepartment.Text == "Cleaning")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "SELECT * FROM ProductsCleaning WHERE Name='" + tbSearch.Text + "'";

                            OleDbDataReader reader = comanda.ExecuteReader();

                            while (reader.Read())
                            {

                                tbPrice.Text = reader["Price"].ToString();
                                tbQuantity.Text = reader["Quantity"].ToString();

                                if (Convert.ToInt32(reader["Quantity"]) > 0)
                                    tbStatus.Text = "Available";
                                else
                                    tbStatus.Text = "Unavailable";

                            }
                            if (tbPrice.Text == "")
                                tbStatus.Text = "Unavailable";

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                    else if (cbDepartment.Text == "Electronics")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "SELECT * FROM ProductsElectronics WHERE Name='" + tbSearch.Text + "'";

                            OleDbDataReader reader = comanda.ExecuteReader();

                            while (reader.Read())
                            {

                                tbPrice.Text = reader["Price"].ToString();
                                tbQuantity.Text = reader["Quantity"].ToString();

                                if (Convert.ToInt32(reader["Quantity"]) > 0)
                                    tbStatus.Text = "Available";
                                else
                                    tbStatus.Text = "Unavailable";

                            }

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                    else if (cbDepartment.Text == "Food")
                    {
                        try
                        {
                            conexiune.Open();
                            OleDbCommand comanda = new OleDbCommand();
                            comanda.Connection = conexiune;
                            comanda.CommandText = "SELECT * FROM ProductsFood WHERE Name='" + tbSearch.Text + "'";

                            OleDbDataReader reader = comanda.ExecuteReader();

                            while (reader.Read())
                            {

                                tbPrice.Text = reader["Price"].ToString();
                                tbQuantity.Text = reader["Quantity"].ToString();

                                if (Convert.ToInt32(reader["Quantity"]) > 0)
                                    tbStatus.Text = "Available";
                                else
                                    tbStatus.Text = "Unavailable";

                            }

                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            conexiune.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

        }

        private void cbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbSearch.Clear();
            tbStatus.Clear();
            tbQuantity.Clear();
            tbPrice.Clear();
        }
    }
}
