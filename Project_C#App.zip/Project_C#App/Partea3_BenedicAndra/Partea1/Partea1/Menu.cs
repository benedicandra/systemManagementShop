﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Partea1
{
    public partial class Menu : Form
    {
        Raion rAlimente = new Raion("Alimente", new List<Object>());
        Raion rElectronice = new Raion("Electronice ", new List<Object>());
        Raion rCuratare = new Raion("Curatare", new List<Object>());
        public Menu()
        {
            InitializeComponent();
            
        }

        private void buyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Buy frm = new Buy();
            frm.Show();
        }
        
        private void addProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddProduct frm = new AddProduct();
            frm.Show();
        }

        private void alimenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Food frm = new Food();
            frm.Show();
        }

        private void electroniceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Electronics frm = new Electronics();
            frm.Show();
        }

        private void curatareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cleaning frm = new Cleaning();
            frm.Show();
        }
        
        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
                this.BackColor = dlg.Color;
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void findProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Find frm = new Find();
            frm.Show();
        }
        
        private void stocksDepartmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stocks_Dep frm = new Stocks_Dep();
            frm.Show();
        }

        private void needsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Needs frm = new Needs();
            frm.Show();
        }
    }
}
